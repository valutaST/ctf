To run use:

```
docker-compose up --build
```